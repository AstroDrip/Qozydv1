'use client';
import { useEffect, useRef } from 'react';

// Render the generated lunar artwork onto the requested 256-pixel texture grid.
// A chroma mask discards the generator's neutral matte without softening pixel edges.
export function moonCanvas(image: HTMLImageElement) {
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = 256;
  const context = canvas.getContext('2d');
  if (!context) return canvas;
  context.imageSmoothingEnabled = false;
  context.drawImage(image, 55, 52, 1144, 1144, 0, 0, 256, 256);
  const pixels = context.getImageData(0, 0, 256, 256);
  for (let i = 0; i < pixels.data.length; i += 4) {
    const r = pixels.data[i], g = pixels.data[i + 1], b = pixels.data[i + 2];
    if (Math.max(r, g, b) - Math.min(r, g, b) < 35 && r > 100) pixels.data[i + 3] = 0;
  }
  context.putImageData(pixels, 0, 0);
  return canvas;
}

export default function PixelMoon({ className = '' }: { className?: string }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    let active = true;
    const image = new Image();
    image.onload = () => { if (active) ref.current?.getContext('2d')?.drawImage(moonCanvas(image), 0, 0); };
    image.src = '/art/blood-moon.png';
    return () => { active = false; };
  }, []);
  return <canvas ref={ref} width={256} height={256} className={`pixel-moon ${className}`} role="img" aria-label="Original QOZYD blood moon, with pixel craters and a glowing lunar canyon" />;
}
